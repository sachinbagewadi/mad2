package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    Switch aSwitch;
    ImageButton btn;
    ConstraintLayout classout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn = findViewById(R.id.btn);
        aSwitch = findViewById(R.id.switch1);
        classout = findViewById(R.id.classout);

        DatePicker datePicker = new DatePicker(this);
        classout.addView(datePicker);
        




        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {
                    btn.setEnabled(true);
                }
                else {
                    btn.setEnabled(false);
                }
            }
        });

    }
}